import time
import sys
import threading
from colorama import init, Fore, Style

init(autoreset=True)

# Colors
USER_COLOR = Fore.GREEN
SYSTEM_COLOR = Fore.YELLOW
ERROR_COLOR = Fore.RED
INFO_COLOR = Fore.CYAN
RESET = Style.RESET_ALL

def print_scroll(text, delay=0.02, color=Fore.GREEN):
    """Print text one char at a time with color."""
    for c in text:
        print(color + c + RESET, end='', flush=True)
        time.sleep(delay)
    print()



def spinner(message, stop_event):
    """Animated spinner with message."""
    spinner_cycle = ['|', '/', '-', '\\']
    idx = 0
    while not stop_event.is_set():
        sys.stdout.write(f"\r{message} {spinner_cycle[idx % len(spinner_cycle)]}")
        sys.stdout.flush()
        idx += 1
        time.sleep(0.1)
    sys.stdout.write("\r" + " " * (len(message) + 2) + "\r")  # clear line

def print_logo():
    logo = r"""
 ____  __   ____   ____  
|  _ \|  \ |  _ \ |  _ \ 
| |_) | | | | |_) || |_) |
|  __/| | | |  __/ |  __/ 
|_|   |_| |_|_|    |_|    
"""
    print_scroll(logo, color=INFO_COLOR)
