from pathlib import Path

ROOT_PATH = Path("pyos_root").resolve()

def resolve_path(cwd: Path, target: str) -> Path:
    new_path = (cwd / target).resolve()
    if ROOT_PATH not in new_path.parents and new_path != ROOT_PATH:
        raise ValueError("Access outside virtual root not allowed.")
    return new_path

def list_dir(cwd: Path):
    try:
        resolved = resolve_path(cwd, ".")
        return [p.name for p in resolved.iterdir()]
    except Exception:
        return []

def change_dir(cwd: Path, target: str) -> Path:
    new_dir = resolve_path(cwd, target)
    if not new_dir.is_dir():
        raise FileNotFoundError(f"{target} is not a directory")
    return new_dir

def read_file(cwd: Path, filename: str):
    fpath = resolve_path(cwd, filename)
    if not fpath.is_file():
        raise FileNotFoundError(f"{filename} not found")
    return fpath.read_text()

def write_file(cwd: Path, filename: str, content: str):
    fpath = resolve_path(cwd, filename)
    fpath.parent.mkdir(parents=True, exist_ok=True)
    fpath.write_text(content)
