import platform
import psutil

def get_cpu_info():
    freq = psutil.cpu_freq()
    return {
        "processor": platform.processor(),
        "architecture": platform.machine(),
        "cores": psutil.cpu_count(logical=False),
        "threads": psutil.cpu_count(logical=True),
        "frequency": freq.current if freq else "Unknown",
        "usage_percent": psutil.cpu_percent(interval=0.5),
    }

def cpu_info_str():
    info = get_cpu_info()
    return (
        f"Processor: {info['processor']}\n"
        f"Architecture: {info['architecture']}\n"
        f"Cores: {info['cores']}\n"
        f"Threads: {info['threads']}\n"
        f"Frequency: {info['frequency']} MHz\n"
        f"Usage: {info['usage_percent']}%\n"
    )
