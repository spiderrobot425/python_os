from modules import memory, utils

def run(cwd, args):
    utils.print_scroll(memory.memory_info_str())
    return cwd
