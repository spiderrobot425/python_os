from modules import utils
from commands import COMMANDS

def run(cwd, args):
    utils.print_scroll("Available commands: " + ", ".join(COMMANDS.keys()))
    return cwd
