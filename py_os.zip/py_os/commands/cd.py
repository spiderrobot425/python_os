from modules import filesystem, utils

def run(cwd, args):
    if not args:
        return filesystem.ROOT_PATH
    try:
        return filesystem.change_dir(cwd, args[0])
    except Exception as e:
        utils.print_scroll(f"Error: {e}")
        return cwd
