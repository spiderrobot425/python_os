import sys
from pathlib import Path
import time
from modules import boot, utils

sys.dont_write_bytecode = True

PYOS_ROOT = Path("pyos_root")
LOGS_PATH = PYOS_ROOT / "logs"

core_dirs = ["bin", "home", "etc", "tmp", "var/log", "mnt", "dev", "logs"]

default_files = {
    "etc/welcome.txt": "Welcome to PyOS!\nThis is your simulated OS.",
    "etc/users.txt": "admin\n",
    "var/log/boot.log": f"[BOOT] PyOS booted at {boot.get_boot_time()}\n",
}

def create_flag():
    flag_path = PYOS_ROOT / "flag.txt"
    try:
        flag_path.write_text("booted")
    except Exception as e:
        utils.print_scroll(f"[ERROR] Failed to write flag.txt: {e}", color=utils.SYSTEM_COLOR)

def is_system_ready():
    return (PYOS_ROOT / "etc" / "users.txt").exists()

def create_folder_structure():
    if is_system_ready():
        utils.print_scroll("PyOS already initialized. Skipping setup.\n", color=utils.SYSTEM_COLOR)
        return

    utils.print_scroll("Initializing PyOS filesystem...\n", color=utils.SYSTEM_COLOR)
    PYOS_ROOT.mkdir(exist_ok=True)

    for folder in core_dirs:
        (PYOS_ROOT / folder).mkdir(parents=True, exist_ok=True)
        utils.print_scroll(f"Created directory: /{folder}", color=utils.SYSTEM_COLOR)
        time.sleep(0.1)

    for filepath, content in default_files.items():
        full_path = PYOS_ROOT / filepath
        full_path.parent.mkdir(parents=True, exist_ok=True)
        full_path.write_text(content)
        utils.print_scroll(f"Wrote system file: /{filepath}", color=utils.SYSTEM_COLOR)
        time.sleep(0.05)

    create_flag()
    utils.print_scroll("PyOS initialization complete.\n", color=utils.SYSTEM_COLOR)

def launch_shell():
    import subprocess
    shell_path = Path(__file__).parent / "shell.py"
    if shell_path.exists():
        utils.print_scroll("Launching PyOS shell...\n", color=utils.SYSTEM_COLOR)
        subprocess.run([sys.executable, str(shell_path)])
    else:
        utils.print_scroll("[ERROR] shell.py not found.", color=utils.SYSTEM_COLOR)

if __name__ == "__main__":
    create_folder_structure()
    launch_shell()
