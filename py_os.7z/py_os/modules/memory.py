import psutil

def get_memory_info():
    mem = psutil.virtual_memory()
    return {
        "total": mem.total,
        "available": mem.available,
        "used": mem.used,
        "percent": mem.percent,
    }

def memory_info_str():
    mem = get_memory_info()
    total_gb = round(mem["total"] / (1024 ** 3), 1)
    avail_gb = round(mem["available"] / (1024 ** 3), 1)
    used_gb = round(mem["used"] / (1024 ** 3), 1)
    usage_percent = round(mem["percent"], 1)

    return (f"Memory Total: {total_gb} GB\n"
            f"Memory Available: {avail_gb} GB\n"
            f"Memory Used: {used_gb} GB\n"
            f"Usage: {usage_percent}%")
