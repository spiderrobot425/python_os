from datetime import datetime

def get_boot_time():
    """Return the current boot time as a formatted string."""
    return datetime.now().strftime('%Y-%m-%d %I:%M:%S %p')
