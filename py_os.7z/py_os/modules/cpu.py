import platform

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ModuleNotFoundError:
    PSUTIL_AVAILABLE = False

def get_cpu_info():
    if PSUTIL_AVAILABLE:
        freq = psutil.cpu_freq()
        cores = psutil.cpu_count(logical=False) or 1
        threads = psutil.cpu_count(logical=True) or cores
        usage = psutil.cpu_percent(interval=0.5)
        freq_val = freq.current if freq else "Unknown"
    else:
        cores = threads = 1
        usage = "Unknown"
        freq_val = "Unknown"

    return {
        "processor": platform.processor() or "Unknown",
        "architecture": platform.machine() or "Unknown",
        "cores": cores,
        "threads": threads,
        "frequency": freq_val,
        "usage_percent": usage,
    }

def cpu_info_str():
    info = get_cpu_info()
    return (
        f"Processor: {info['processor']}\n"
        f"Architecture: {info['architecture']}\n"
        f"Cores: {info['cores']}\n"
        f"Threads: {info['threads']}\n"
        f"Frequency: {info['frequency']} MHz\n"
        f"Usage: {info['usage_percent']}%\n"
    )
