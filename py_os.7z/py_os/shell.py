import sys
from pathlib import Path
from threading import Thread, Event
from modules import filesystem, utils
from commands import COMMANDS

sys.dont_write_bytecode = True

cwd = filesystem.ROOT_PATH

def shell_prompt(cwd: Path):
    import os
    username = os.getenv("USERNAME") or os.getenv("USER") or "user"
    root = filesystem.ROOT_PATH
    try:
        rel_path = cwd.resolve().relative_to(root)
        path_str = "C:\\" + str(rel_path).replace("/", "\\")
    except ValueError:
        path_str = str(cwd.resolve()).replace("/", "\\")
    return f"{utils.USER_COLOR}{username}{utils.RESET} {path_str}> "

def main():
    global cwd
    

    utils.print_logo()
    utils.print_scroll("Welcome to PyOS shell! Type 'help' for commands.\n", color=utils.SYSTEM_COLOR)

    while True:
        try:
            user_input = input(shell_prompt(cwd)).strip()
        except (EOFError, KeyboardInterrupt):


            utils.print_scroll("\nExiting PyOS shell. Goodbye!", color=utils.SYSTEM_COLOR)
            break

        parts = user_input.split()
        cmd = parts[0].lower()
        args = parts[1:]

        if cmd in COMMANDS:
            new_cwd = COMMANDS[cmd](cwd, args)
            if new_cwd is not None:
                cwd = new_cwd
        else:
            utils.print_scroll(f"Unknown command: {cmd}", color=utils.ERROR_COLOR)

if __name__ == "__main__":
    main()
