from modules import filesystem, utils

def run(cwd, args):
    if not args:
        utils.print_scroll("Usage: cat <filename>")
        return cwd
    try:
        content = filesystem.read_file(cwd, args[0])
        print(content)
    except Exception as e:
        utils.print_scroll(f"Error: {e}")
    return cwd
