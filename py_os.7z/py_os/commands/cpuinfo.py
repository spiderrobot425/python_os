from modules import cpu, utils

def run(cwd, args):
    utils.print_scroll(cpu.cpu_info_str())
    return cwd
