import importlib
import os

COMMANDS = {}

def load_commands():
    commands_path = os.path.dirname(__file__)
    for filename in os.listdir(commands_path):
        if filename.endswith(".py") and filename != "__init__.py":
            cmd_name = filename[:-3]
            module = importlib.import_module(f"commands.{cmd_name}")
            COMMANDS[cmd_name] = module.run

load_commands()
