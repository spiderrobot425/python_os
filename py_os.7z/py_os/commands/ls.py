from modules import filesystem, utils

def run(cwd, args):
    try:
        contents = filesystem.list_dir(cwd)
        utils.print_scroll("  ".join(contents))
    except Exception as e:
        utils.print_scroll(f"Error: {e}")
    return cwd
